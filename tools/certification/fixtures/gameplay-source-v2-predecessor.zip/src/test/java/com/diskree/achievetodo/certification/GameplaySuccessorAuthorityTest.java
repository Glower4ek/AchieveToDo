package com.diskree.achievetodo.certification;
import org.junit.jupiter.api.Test;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;
/** Full standard-suite source controls; historical runtime evidence remains historical. */
public final class GameplaySuccessorAuthorityTest {
 @Test void currentSourceAndTamperControls() throws Exception {
  String authority=System.getenv("ACHIEVETODO_GAMEPLAY_SOURCE_AUTHORITY");
  if (authority==null) return;
  assertTrue(authority.equals("ATD_PURPUR_GAMEPLAY_SOURCE_V1") || authority.equals("ATD_PURPUR_GAMEPLAY_SOURCE_V2"),"Unknown gameplay authority");
  UiUxMaintenanceSourceContract.verifyRoot(Path.of("").toAbsolutePath());
  // V2's exact-current control also runs all four unchanged V1 controls on authenticated originals.
  String controls=authority.equals("ATD_PURPUR_GAMEPLAY_SOURCE_V2") ? "tools.build.tests.test_gameplay_successor_v2" : "tools.build.tests.test_gameplay_successor";
  var builder=new ProcessBuilder(System.getenv("ACHIEVETODO_PYTHON"),"-B","-X","utf8","-m","unittest",controls,"-v").redirectErrorStream(true);
  var process=builder.start();var output=new String(process.getInputStream().readAllBytes(),StandardCharsets.UTF_8);
  assertEquals(0,process.waitFor(),output);
 }
}
