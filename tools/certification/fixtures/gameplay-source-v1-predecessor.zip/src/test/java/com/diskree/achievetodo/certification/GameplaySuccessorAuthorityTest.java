package com.diskree.achievetodo.certification;
import org.junit.jupiter.api.Test;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;
/** Full standard-suite source controls; historical runtime evidence remains historical. */
public final class GameplaySuccessorAuthorityTest {
 @Test void currentSourceAndTamperControls() throws Exception {
  if (System.getenv("ACHIEVETODO_GAMEPLAY_SOURCE_AUTHORITY")==null) return;
  UiUxMaintenanceSourceContract.verifyRoot(Path.of("").toAbsolutePath());
  var builder=new ProcessBuilder(System.getenv("ACHIEVETODO_PYTHON"),"-B","-X","utf8","-m","unittest","tools.build.tests.test_gameplay_successor","-v").redirectErrorStream(true);
  var process=builder.start();var output=new String(process.getInputStream().readAllBytes(),StandardCharsets.UTF_8);
  assertEquals(0,process.waitFor(),output);
 }
}
